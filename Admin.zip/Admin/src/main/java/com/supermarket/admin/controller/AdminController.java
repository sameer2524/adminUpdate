package com.supermarket.admin.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.supermarket.admin.model.Admin;
import com.supermarket.admin.repository.AdminOperation;

@RestController
@RequestMapping("/api")
public class AdminController {

    @Autowired
    AdminOperation Repository;

    // Get All Notes
    @GetMapping("/products")
    public List<Admin> getAllProducts() {
        return (List<Admin>) Repository.findAll();
    }

    // Create a new Note
    @PostMapping("/products")
    public Admin createProduct(@Valid @RequestBody Admin note) {
        return Repository.save(note);
    }

    // Get a Single Note
    @GetMapping("/products/{id}")
    public Admin getProductById(@PathVariable(value = "id") Long productId) {
        return Repository.findById(productId)
           .orElseThrow(() -> new ResourceNotFoundException("Admin"));
    }

    // Update a Note
    @PutMapping("/products/{id}")
    public Admin updateProduct(@PathVariable(value = "id") Long productId,
                                            @Valid @RequestBody Admin noteDetails) {

    	Admin note = Repository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Admin"));
    	 note.setProductname(noteDetails.getProductname());
        note.setProductdescription(noteDetails.getProductdescription());
        note.setProductprice(noteDetails.getProductprice());
        note.setProductquantity(noteDetails.getProductquantity());

      Admin updatedProducts = Repository.save(note);
        return updatedProducts;
    }

    // Delete a Product
    @DeleteMapping("/products/{id}")
    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long productId) {
        Admin product = Repository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Admin"));

        Repository.delete(product);

        return ResponseEntity.ok().build();
    }
}