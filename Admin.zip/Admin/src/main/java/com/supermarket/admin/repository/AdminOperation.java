package com.supermarket.admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.supermarket.admin.model.Admin;

public interface AdminOperation extends CrudRepository<Admin, Long> {

}
